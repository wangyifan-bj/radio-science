
nt=1000;
nr=100:10:250;
pi=3.1415926;
u=4*pi*10^(-7);
pt=64;
at=1;
ar=0.1;
Rt=nt*2*pi*at*0.128;
I=sqrt(pt/Rt);
Sr=pi*ar*ar;
Rr=2*nr*pi*ar*0.128*10;
fre=1:100000;
r=300;
theta=0.2;
sig=2/pi*atan(0.01*(theta)^1.95);

l1=0.5*u*pi*nr.*nr*ar;
Ufmax=zeros(1,length(nr));
z=zeros(length(nr),length(fre));
fmv=zeros(1,length(nr));
bb=zeros(1,length(nr));


for i=1:length(nr)
    syms f;
    U=@(f)(0.707*I*nt*nr(i)*pi*u*at^2*Sr/(r^3)*f*exp(-1*sqrt(pi*u*sig.*f)*r));
    Ufmax(i)=fminbnd(inline(-U(f)),1,100000);
    c=1/((2*pi*Ufmax(i))^2*l1(i));
    z=Rr(i)+1i*2*pi.*fre*l1(i);
    z1=Rr(i)-1i./(2*pi.*fre*c);
    e=0.707*I*nt*nr(i)*pi*u*at^2*Sr/(r^3).*fre.*exp(-1*sqrt(pi*u*sig.*fre)*r);
    p=Rr(i).*((e./abs(z+z1)).^2);
    [~,fm]=max(p);
    [~,fl]=min(abs(p(1:fm)-p(fm)/2));
    [~,fh]=min(abs(p(fm:end)-p(fm)/2));
    bb(i)=fh+fm-fl-1;
end


figure
plot(nr,bb/1000,'g-o');
hold on
plot(nr,bb2/1000,'r-.');
hold on
plot(nr,bb3/1000,'b-*');
ylabel('\it{B}_{\itw}\rm{/kHz}') 
xlabel('\it{N}_{\itr}');
lgd =legend({'\it{r}\rm{=200m}','\it{r}\rm{=400m}','\it{r}\rm{=500m}'});
lgd.ItemTokenSize = [11, 12];
ax = gca;
ax.FontSize = 12;
ax.FontName = 'Times New Roman';
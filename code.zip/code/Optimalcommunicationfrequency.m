nt=1000;
nr=200;
pi=3.1415926;
u=4*pi*10^(-7);
at=1;
ar=0.2;
Rt=nt*2*pi*at*0.128;
Rr=nr*2*pi*ar*0.128*10;
fre1=25000:200:60000;
fre2=15000:200:50000;
fre3=10000:200:40000;
r1=300;
r2=350;
r3=400;
theta=0.2;
sig=2/pi*atan(0.01*(theta)^1.95);
J=1.4148;

L1=-10.*log10(J^2*pi^4*nt^2*nr^2*u^2*at^4*ar^4.*fre1.^2.*exp(-2*sqrt(pi*u*sig.*fre1).*r1)./(16*Rt*Rr.*(r1.^6)));
L2=-10.*log10(J^2*pi^4*nt^2*nr^2*u^2*at^4*ar^4.*fre2.^2.*exp(-2*sqrt(pi*u*sig.*fre2).*r2)./(16*Rt*Rr.*(r2.^6)));
L3=-10.*log10(J^2*pi^4*nt^2*nr^2*u^2*at^4*ar^4.*fre3.^2.*exp(-2*sqrt(pi*u*sig.*fre3).*r3)./(16*Rt*Rr.*(r3.^6)));




figure
t=tiledlayout(1,3);
t.TileSpacing = 'tight';
t.Padding = 'tight';
 
nexttile
plot(fre1,L1,'b');
title('\rm{(a)}\it{r}\rm{=300m}')
xlabel('\it{f}\rm{/Hz}') 
ylabel('\it{L}\rm{/dB}') 
ax = gca;
ax.FontSize = 12;
ax.FontName = 'Times New Roman';


nexttile
plot(fre2,L2,'b');
title('\rm{(b)}\it{r}\rm{=350m}')
xlabel('\it{f}\rm{/Hz}') 
ax = gca;
ax.FontSize = 12;
ax.FontName = 'Times New Roman';

nexttile
plot(fre3,L3,'b');
title('\rm{(c)}\it{r}\rm{=400m}')
xlabel('\it{f}\rm{/Hz}') 
ax = gca;
ax.FontSize = 12;
ax.FontName = 'Times New Roman';




ser=0.001;
nt=1000;
nr=100;
pi=3.1415926;
u=4*pi*10^(-7);
pt=64;
at=1;
ar=0.1;
Rt=nt*2*pi*at*0.128;
I=sqrt(pt/Rt);
Sr=pi*ar*ar;
Rr=nr*2*pi*ar*0.128*10;
fre=1:100000;
r2=200:2:430;
theta=0.2;
sig=2/pi*atan(0.01*(theta)^1.95);

l1=0.5*u*pi*nr*nr*ar;
Ufmax=zeros(1,length(r2));
z=zeros(length(r2),length(fre));
fmv=zeros(1,length(r2));
b=zeros(1,length(r2));
log2_m=zeros(1,length(r2));


for i=1:length(r2)
    syms f;
    r=r2(i);
    U=@(f)(0.707*I*nt*nr*pi*u*at^2*Sr/(r^3)*f*exp(-1*sqrt(pi*u*sig.*f)*r));
    Ufmax(i)=fminbnd(inline(-U(f)),1,100000);
    c=1/((2*pi*Ufmax(i))^2*l1);
    z=Rr+1i*2*pi.*fre*l1;
    z1=Rr-1i./(2*pi.*fre*c);
    e=0.707*I*nt*nr*pi*u*at^2*Sr/(r2(i)^3).*fre.*exp(-1*sqrt(pi*u*sig.*fre)*r2(i));
    p=Rr.*((e./abs(z+z1)).^2);
    pr=max(p);
    [~,fm]=max(p);
    [~,fl]=min(abs(p(1:fm)-p(fm)/2));
    [~,fh]=min(abs(p(fm:end)-p(fm)/2));
    b=fh+fm-fl-1;
    pn=1.38*10^(-23)*(290+r2(i)/50)*b;
    snr=pr/pn;
    m=2.^floor(log2((1+3.*snr)/((qfuncinv(ser/4))^2)));
%     if m>1
    log2_m(i)= log2(m);
%     end
end

power_range = 1:10;

figure;

plot(r2, log2_m, 'o');
hold on;
% plot(r2,log2_m2,'*');
% hold on;
% plot(r2,log2_m3,'^');
% hold on;
% plot(r2,log2_m4,'x');

yticks(power_range);  
yticklabels({'BPSK','QPSK','8QAM','16QAM','32QAM','64QAM','128QAM','256QAM','512QAM','1024QAM'});

ylabel('\it{M}');
% ylabel('Modulation scheme');
% xlabel('\it{r}\rm{/m}');
xlabel('\it{r}\rm{/m}');
legend({'\it{N}_{\itr}\rm{=100};\it{a}_{\itr}\rm{=0.1m}','\it{N}_{\itr}\rm{=150};\it{a}_{\itr}\rm{=0.1m}', ...
    '\it{N}_{\itr}\rm{=100};\it{a}_{\itr}\rm{=0.15m}','\it{N}_{\itr}\rm{=150};\it{a}_{\itr}\rm{=0.15m}'});
grid on;
ax = gca;
ax.FontSize = 12;
ax.FontName = 'Times New Roman';
nt=1000;
nr=200;
pi=3.1415926;
u=4*pi*10^(-7);
at=1;
ar=0.1;
Rt0=0.128;
Rr0=1.28;
Rt=nt*2*pi*at*0.128;
Rr=nr*2*pi*ar*0.128*10;
fre=10000;
r=200:20:500;
theta=0.2;
sig=2/pi*atan(0.01*(theta)^1.95);
J=1.4148;

L=-10.*log10(J^2*nt^2*nr^2*pi^4*fre^2*u^2*at^4*ar^4.*exp(-2*sqrt(pi*u*sig*fre).*r)./(16*Rt*Rr.*(r.^6)));
L2=23.4-10*log10(J^2*nt*nr*at^3*ar^3/(Rt0*Rr0*sig^2))+100.*log10(r);




figure
plot(r,L,'g--');
hold on 
plot(r,L2,'r-.');
ylabel('\it{L}\rm{/dB}');
xlabel('\it{r}\rm{/m}');
lgd =legend('\it{f}\rm{=10kHz}','\it{f}={f}_{\rm0}');
lgd.ItemTokenSize = [11, 12];
ax = gca;
ax.FontSize = 12;
ax.FontName = 'Times New Roman';
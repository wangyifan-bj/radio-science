
nt=1000;
nr=100;
pi=3.1415926;
u=4*pi*10^(-7);
pt=64;
at=1;
ar=0.05;
Rt=nt*2*pi*at*0.128;
I=sqrt(pt/Rt);
Sr=pi*ar*ar;
Rr=nr*2*pi*ar*0.128*10;
fre=1:100000;
r2=200:20:500;
theta=0.2;
sig=2/pi*atan(0.01*(theta)^1.95);

l1=0.5*u*pi*nr*nr*ar;
Ufmax=zeros(1,length(r2));
z=zeros(length(r2),length(fre));
fmv=zeros(1,length(r2));
C=zeros(1,length(r2));


for i=1:length(r2)
    syms f;
    r=r2(i);
    U=@(f)(0.707*I*nt*nr*pi*u*at^2*Sr/(r^3)*f*exp(-1*sqrt(pi*u*sig.*f)*r));
    Ufmax(i)=fminbnd(inline(-U(f)),1,100000);
    c=1/((2*pi*Ufmax(i))^2*l1);
    z=Rr+1i*2*pi.*fre*l1;
    z1=Rr-1i./(2*pi.*fre*c);
    e=0.707*I*nt*nr*pi*u*at^2*Sr/(r2(i)^3).*fre.*exp(-1*sqrt(pi*u*sig.*fre)*r2(i));
    p=Rr.*((e./abs(z+z1)).^2);
    pr=max(p);
    [~,fm]=max(p);
    [~,fl]=min(abs(p(1:fm)-p(fm)/2));
    [~,fh]=min(abs(p(fm:end)-p(fm)/2));
    b=fh+fm-fl-1;
    pn=1.38*10^(-23)*(290+r2(i)/50)*b;
    C(i)=b*log2(1+pr/pn);
end


figure
plot(r2,C/1000,'r-+');
ylabel('\it{C}\rm{/kbps}') 
xlabel('\it{r}\rm{/m}');
lgd =legend({'\it{N}_{\itr}\rm{=100};\it{a}_{\itr}\rm{=0.05m}'});
lgd.ItemTokenSize = [11, 12];
ax = gca;
ax.FontSize = 12;
ax.FontName = 'Times New Roman';